<?php

define('TEXT_MODULE_YANDEX_DISK_TITLE','Яндекс.Диск');
define('TEXT_MODULE_YANDEX_DISK_ACCESS_TOKEN','OAuth-токен');
define('TEXT_MODULE_YANDEX_DISK_ACCESS_TOKEN_INFO','<a href="https://tech.yandex.ru/oauth/doc/dg/reference/web-client-docpage/" target="_balnk">Получение токена для веб-приложения</a>');