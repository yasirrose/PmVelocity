<?php

namespace Yandex\Market\Content\Models;

class ResponsePopularCategoryModelsGet extends ResponsePopularModelsGet
{
}
