<?php

namespace Yandex\Market\Content\Models;

class ResponseGeoRegionSuggestGet extends ResponseGeoRegionsGet
{
}
