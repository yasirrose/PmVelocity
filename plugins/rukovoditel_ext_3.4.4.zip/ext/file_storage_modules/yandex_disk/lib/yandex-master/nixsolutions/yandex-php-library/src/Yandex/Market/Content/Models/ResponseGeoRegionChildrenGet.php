<?php

namespace Yandex\Market\Content\Models;

class ResponseGeoRegionChildrenGet extends ResponseGeoRegionsGet
{
}
