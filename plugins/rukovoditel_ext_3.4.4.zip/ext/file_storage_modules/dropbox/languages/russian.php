<?php

define('TEXT_MODULE_DROPBOX_TITLE','Dropbox');
define('TEXT_MODULE_DROPBOX_ACCESS_TOKEN_INFO','<a href="https://www.dropbox.com/developers/apps" target="_blank">Создайте новое приложение, чтобы получить ключ приложения</a>');