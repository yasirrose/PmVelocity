#Rukovoditel 3.4.4;
#Minor;

DROP TABLE IF EXISTS app_access_groups;
DROP TABLE IF EXISTS app_access_rules;
DROP TABLE IF EXISTS app_access_rules_fields;
DROP TABLE IF EXISTS app_approved_items;
DROP TABLE IF EXISTS app_attachments;
DROP TABLE IF EXISTS app_comments;
DROP TABLE IF EXISTS app_comments_access;
DROP TABLE IF EXISTS app_comments_forms_tabs;
DROP TABLE IF EXISTS app_comments_history;
DROP TABLE IF EXISTS app_configuration;
DROP TABLE IF EXISTS app_custom_php;
DROP TABLE IF EXISTS app_dashboard_pages;
DROP TABLE IF EXISTS app_dashboard_pages_sections;
DROP TABLE IF EXISTS app_emails_on_schedule;
DROP TABLE IF EXISTS app_entities;
DROP TABLE IF EXISTS app_entities_access;
DROP TABLE IF EXISTS app_entities_configuration;
DROP TABLE IF EXISTS app_entities_groups;
DROP TABLE IF EXISTS app_entities_menu;
DROP TABLE IF EXISTS app_entity_1;
DROP TABLE IF EXISTS app_entity_1_values;
DROP TABLE IF EXISTS app_entity_21;
DROP TABLE IF EXISTS app_entity_21_values;
DROP TABLE IF EXISTS app_entity_22;
DROP TABLE IF EXISTS app_entity_22_values;
DROP TABLE IF EXISTS app_entity_23;
DROP TABLE IF EXISTS app_entity_23_values;
DROP TABLE IF EXISTS app_entity_24;
DROP TABLE IF EXISTS app_entity_24_values;
DROP TABLE IF EXISTS app_entity_25;
DROP TABLE IF EXISTS app_entity_25_values;
DROP TABLE IF EXISTS app_ext_calendar;
DROP TABLE IF EXISTS app_ext_calendar_access;
DROP TABLE IF EXISTS app_ext_calendar_events;
DROP TABLE IF EXISTS app_ext_call_history;
DROP TABLE IF EXISTS app_ext_chat_access;
DROP TABLE IF EXISTS app_ext_chat_conversations;
DROP TABLE IF EXISTS app_ext_chat_conversations_messages;
DROP TABLE IF EXISTS app_ext_chat_messages;
DROP TABLE IF EXISTS app_ext_chat_unread_messages;
DROP TABLE IF EXISTS app_ext_chat_users_online;
DROP TABLE IF EXISTS app_ext_comments_templates;
DROP TABLE IF EXISTS app_ext_comments_templates_fields;
DROP TABLE IF EXISTS app_ext_cryptopro_certificates;
DROP TABLE IF EXISTS app_ext_currencies;
DROP TABLE IF EXISTS app_ext_email_notification_rules;
DROP TABLE IF EXISTS app_ext_email_rules;
DROP TABLE IF EXISTS app_ext_email_rules_blocks;
DROP TABLE IF EXISTS app_ext_entities_templates;
DROP TABLE IF EXISTS app_ext_entities_templates_fields;
DROP TABLE IF EXISTS app_ext_export_selected;
DROP TABLE IF EXISTS app_ext_export_selected_blocks;
DROP TABLE IF EXISTS app_ext_export_templates;
DROP TABLE IF EXISTS app_ext_file_storage_queue;
DROP TABLE IF EXISTS app_ext_file_storage_rules;
DROP TABLE IF EXISTS app_ext_functions;
DROP TABLE IF EXISTS app_ext_funnelchart;
DROP TABLE IF EXISTS app_ext_ganttchart;
DROP TABLE IF EXISTS app_ext_ganttchart_access;
DROP TABLE IF EXISTS app_ext_ganttchart_depends;
DROP TABLE IF EXISTS app_ext_global_search_entities;
DROP TABLE IF EXISTS app_ext_graphicreport;
DROP TABLE IF EXISTS app_ext_image_map;
DROP TABLE IF EXISTS app_ext_import_templates;
DROP TABLE IF EXISTS app_ext_ipages;
DROP TABLE IF EXISTS app_ext_item_pivot_tables;
DROP TABLE IF EXISTS app_ext_item_pivot_tables_calcs;
DROP TABLE IF EXISTS app_ext_items_export_templates_blocks;
DROP TABLE IF EXISTS app_ext_kanban;
DROP TABLE IF EXISTS app_ext_mail;
DROP TABLE IF EXISTS app_ext_mail_accounts;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_fields;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_filters;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_rules;
DROP TABLE IF EXISTS app_ext_mail_accounts_users;
DROP TABLE IF EXISTS app_ext_mail_contacts;
DROP TABLE IF EXISTS app_ext_mail_filters;
DROP TABLE IF EXISTS app_ext_mail_groups;
DROP TABLE IF EXISTS app_ext_mail_groups_from;
DROP TABLE IF EXISTS app_ext_mail_templates;
DROP TABLE IF EXISTS app_ext_mail_to_items;
DROP TABLE IF EXISTS app_ext_map_reports;
DROP TABLE IF EXISTS app_ext_mind_map;
DROP TABLE IF EXISTS app_ext_modules;
DROP TABLE IF EXISTS app_ext_modules_cfg;
DROP TABLE IF EXISTS app_ext_pivot_calendars;
DROP TABLE IF EXISTS app_ext_pivot_calendars_entities;
DROP TABLE IF EXISTS app_ext_pivot_map_reports;
DROP TABLE IF EXISTS app_ext_pivot_map_reports_entities;
DROP TABLE IF EXISTS app_ext_pivot_tables;
DROP TABLE IF EXISTS app_ext_pivot_tables_fields;
DROP TABLE IF EXISTS app_ext_pivot_tables_settings;
DROP TABLE IF EXISTS app_ext_pivotreports;
DROP TABLE IF EXISTS app_ext_pivotreports_fields;
DROP TABLE IF EXISTS app_ext_pivotreports_settings;
DROP TABLE IF EXISTS app_ext_process_form_rows;
DROP TABLE IF EXISTS app_ext_process_form_tabs;
DROP TABLE IF EXISTS app_ext_processes;
DROP TABLE IF EXISTS app_ext_processes_actions;
DROP TABLE IF EXISTS app_ext_processes_actions_fields;
DROP TABLE IF EXISTS app_ext_processes_buttons_groups;
DROP TABLE IF EXISTS app_ext_processes_clone_subitems;
DROP TABLE IF EXISTS app_ext_public_forms;
DROP TABLE IF EXISTS app_ext_recurring_tasks;
DROP TABLE IF EXISTS app_ext_recurring_tasks_fields;
DROP TABLE IF EXISTS app_ext_report_page;
DROP TABLE IF EXISTS app_ext_report_page_blocks;
DROP TABLE IF EXISTS app_ext_resource_timeline;
DROP TABLE IF EXISTS app_ext_resource_timeline_entities;
DROP TABLE IF EXISTS app_ext_rss_feeds;
DROP TABLE IF EXISTS app_ext_signed_items;
DROP TABLE IF EXISTS app_ext_signed_items_signatures;
DROP TABLE IF EXISTS app_ext_smart_input_rules;
DROP TABLE IF EXISTS app_ext_sms_rules;
DROP TABLE IF EXISTS app_ext_subscribe_rules;
DROP TABLE IF EXISTS app_ext_timeline_reports;
DROP TABLE IF EXISTS app_ext_timer;
DROP TABLE IF EXISTS app_ext_timer_configuration;
DROP TABLE IF EXISTS app_ext_track_changes;
DROP TABLE IF EXISTS app_ext_track_changes_entities;
DROP TABLE IF EXISTS app_ext_track_changes_log;
DROP TABLE IF EXISTS app_ext_track_changes_log_fields;
DROP TABLE IF EXISTS app_ext_xml_export_templates;
DROP TABLE IF EXISTS app_ext_xml_import_templates;
DROP TABLE IF EXISTS app_favorites;
DROP TABLE IF EXISTS app_fields;
DROP TABLE IF EXISTS app_fields_access;
DROP TABLE IF EXISTS app_fields_choices;
DROP TABLE IF EXISTS app_filters_panels;
DROP TABLE IF EXISTS app_filters_panels_fields;
DROP TABLE IF EXISTS app_forms_fields_rules;
DROP TABLE IF EXISTS app_forms_rows;
DROP TABLE IF EXISTS app_forms_tabs;
DROP TABLE IF EXISTS app_global_lists;
DROP TABLE IF EXISTS app_global_lists_choices;
DROP TABLE IF EXISTS app_global_vars;
DROP TABLE IF EXISTS app_help_pages;
DROP TABLE IF EXISTS app_holidays;
DROP TABLE IF EXISTS app_image_map_labels;
DROP TABLE IF EXISTS app_image_map_markers;
DROP TABLE IF EXISTS app_image_map_markers_nested;
DROP TABLE IF EXISTS app_items_export_templates;
DROP TABLE IF EXISTS app_listing_highlight_rules;
DROP TABLE IF EXISTS app_listing_sections;
DROP TABLE IF EXISTS app_listing_types;
DROP TABLE IF EXISTS app_logs;
DROP TABLE IF EXISTS app_mind_map;
DROP TABLE IF EXISTS app_nested_entities_menu;
DROP TABLE IF EXISTS app_portlets;
DROP TABLE IF EXISTS app_records_visibility_rules;
DROP TABLE IF EXISTS app_related_items_21_25;
DROP TABLE IF EXISTS app_reports;
DROP TABLE IF EXISTS app_reports_filters;
DROP TABLE IF EXISTS app_reports_filters_templates;
DROP TABLE IF EXISTS app_reports_groups;
DROP TABLE IF EXISTS app_reports_sections;
DROP TABLE IF EXISTS app_sessions;
DROP TABLE IF EXISTS app_user_filters_values;
DROP TABLE IF EXISTS app_user_roles;
DROP TABLE IF EXISTS app_user_roles_access;
DROP TABLE IF EXISTS app_user_roles_to_items;
DROP TABLE IF EXISTS app_users_alerts;
DROP TABLE IF EXISTS app_users_alerts_viewed;
DROP TABLE IF EXISTS app_users_configuration;
DROP TABLE IF EXISTS app_users_filters;
DROP TABLE IF EXISTS app_users_login_log;
DROP TABLE IF EXISTS app_users_notifications;
DROP TABLE IF EXISTS app_users_search_settings;


CREATE TABLE IF NOT EXISTS `app_access_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_ldap_default` tinyint(1) DEFAULT NULL,
  `ldap_filter` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_access_groups VALUES
('4','Manager','1','0','','2',''),
('5','Developer','0','0','','1',''),
('6','Client','0','0','','0','');

CREATE TABLE IF NOT EXISTS `app_access_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(10) unsigned NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  `choices` text NOT NULL,
  `users_groups` text NOT NULL,
  `access_schema` text NOT NULL,
  `fields_view_only_access` text NOT NULL,
  `comments_access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_access_rules_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(10) unsigned NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_approved_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `signature` text NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_token` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_added` date NOT NULL,
  `container` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `is_auto` tinyint(1) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(64) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `description` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_comments_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_comments_access VALUES
('4','21','6','view,create'),
('5','21','5','view,create'),
('6','21','4','view,create,update,delete'),
('7','22','5','view,create'),
('8','22','4','view,create,update,delete'),
('9','23','6','view,create'),
('10','23','4','view,create,update,delete'),
('11','24','5','view,create'),
('12','24','4','view,create,update,delete');

CREATE TABLE IF NOT EXISTS `app_comments_forms_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_comments_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `fields_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_comments_id` (`comments_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_configuration VALUES
('9','CFG_APP_NAME','PM Next'),
('10','CFG_APP_SHORT_NAME','PM Next'),
('11','CFG_APP_LOGO',''),
('12','CFG_EMAIL_USE_NOTIFICATION','1'),
('13','CFG_EMAIL_SUBJECT_LABEL',''),
('14','CFG_EMAIL_AMOUNT_PREVIOUS_COMMENTS','2'),
('15','CFG_EMAIL_COPY_SENDER','0'),
('16','CFG_EMAIL_SEND_FROM_SINGLE','0'),
('17','CFG_EMAIL_ADDRESS_FROM','noreply@noreply.com'),
('18','CFG_EMAIL_NAME_FROM','noreply'),
('19','CFG_EMAIL_USE_SMTP','0'),
('20','CFG_EMAIL_SMTP_SERVER',''),
('21','CFG_EMAIL_SMTP_PORT',''),
('22','CFG_EMAIL_SMTP_ENCRYPTION',''),
('23','CFG_EMAIL_SMTP_LOGIN',''),
('24','CFG_EMAIL_SMTP_PASSWORD',''),
('25','CFG_LDAP_USE','0'),
('26','CFG_LDAP_SERVER_NAME',''),
('27','CFG_LDAP_SERVER_PORT',''),
('28','CFG_LDAP_BASE_DN',''),
('29','CFG_LDAP_UID',''),
('30','CFG_LDAP_USER',''),
('31','CFG_LDAP_EMAIL_ATTRIBUTE',''),
('32','CFG_LDAP_USER_DN',''),
('33','CFG_LDAP_PASSWORD',''),
('34','CFG_LOGIN_PAGE_HEADING',''),
('35','CFG_LOGIN_PAGE_CONTENT',''),
('36','CFG_APP_TIMEZONE','America/New_York'),
('37','CFG_APP_DATE_FORMAT','m/d/Y'),
('38','CFG_APP_DATETIME_FORMAT','m/d/Y H:i'),
('39','CFG_APP_ROWS_PER_PAGE','10'),
('40','CFG_REGISTRATION_EMAIL_SUBJECT',''),
('41','CFG_REGISTRATION_EMAIL_BODY',''),
('42','CFG_PASSWORD_MIN_LENGTH','5'),
('43','CFG_APP_LANGUAGE','english.php'),
('44','CFG_APP_SKIN',''),
('45','CFG_PUBLIC_USER_PROFILE_FIELDS',''),
('46','CFG_PLUGIN_EXT_INSTALLED','1'),
('47','CFG_PLUGIN_EXT_LICENSE_KEY','146721427960261545813231141481454112969137551519615851129691414814541153271310060261296914541');

CREATE TABLE IF NOT EXISTS `app_custom_php` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_folder` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` longtext NOT NULL,
  `notes` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_dashboard_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) NOT NULL,
  `sections_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `color` varchar(16) NOT NULL,
  `users_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_sections_id` (`sections_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_dashboard_pages VALUES
('1','1','0','info_block','1','','','τεστ','default','','','0'),
('2','1','0','page','1','τεστ','','&tau;&epsilon;&sigma;&tau;','default','','','0');

CREATE TABLE IF NOT EXISTS `app_dashboard_pages_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grid` tinyint(1) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_emails_on_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_added` bigint(20) unsigned NOT NULL,
  `email_to` varchar(255) NOT NULL,
  `email_to_name` varchar(255) NOT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email_body` text NOT NULL,
  `email_from` varchar(255) NOT NULL,
  `email_from_name` varchar(255) NOT NULL,
  `email_attachments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `display_in_menu` tinyint(1) DEFAULT 0,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entities VALUES
('1','0','0','Users','','0','10'),
('21','0','0','Projects','','0','1'),
('22','21','0','Tasks','','0','1'),
('23','21','0','Tickets','','0','2'),
('24','21','0','Discussions','','0','3'),
('25','0','0','Εργασίες Διοικητή','','0','1');

CREATE TABLE IF NOT EXISTS `app_entities_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entities_access VALUES
('28','21','6','view_assigned'),
('29','21','5','view_assigned,reports'),
('30','21','4','view,create,update,delete,reports'),
('31','22','6',''),
('32','22','5','view,create,update,reports'),
('33','22','4','view,create,update,delete,reports'),
('34','23','6','view_assigned,create,update,reports'),
('35','23','5',''),
('36','23','4','view,create,update,delete,reports'),
('37','24','6',''),
('38','24','5','view_assigned,create,update,delete,reports'),
('39','24','4','view,create,update,delete,reports');

CREATE TABLE IF NOT EXISTS `app_entities_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entities_configuration VALUES
('11','1','menu_title','Users'),
('12','1','listing_heading','Users'),
('13','1','window_heading','User Info'),
('14','1','insert_button','Add User'),
('15','1','use_comments','0'),
('25','21','menu_title',' Projects'),
('26','21','listing_heading',' Projects'),
('27','21','window_heading','Project Info'),
('28','21','insert_button','Add Project'),
('29','21','email_subject_new_item','New Project:'),
('30','21','use_comments','1'),
('31','21','email_subject_new_comment','New project comment:'),
('32','22','menu_title','Tasks'),
('33','22','listing_heading','Tasks'),
('34','22','window_heading','Task Info'),
('35','22','insert_button','Add Task'),
('36','22','email_subject_new_item','New Task'),
('37','22','use_comments','1'),
('38','22','email_subject_new_comment','New task comment:'),
('39','23','menu_title','Tickets'),
('40','23','listing_heading','Tickets'),
('41','23','window_heading','Ticket Info'),
('42','23','insert_button','Add Ticket'),
('43','23','email_subject_new_item','New Ticket:'),
('44','23','use_comments','1'),
('45','23','email_subject_new_comment','New ticket comment'),
('46','24','menu_title','Discussions'),
('47','24','listing_heading','Discussions'),
('48','24','window_heading','Discussion Info'),
('49','24','insert_button','Add Discussion'),
('50','24','email_subject_new_item','New Discussion:'),
('51','24','use_comments','1'),
('52','24','email_subject_new_comment','New discussion comment:'),
('53','21','use_editor_in_comments','0'),
('54','22','use_editor_in_comments','0'),
('55','23','use_editor_in_comments','0'),
('56','24','use_editor_in_comments','0'),
('57','25','menu_title','Αναθέσεις Διοικητή'),
('58','25','menu_icon',''),
('59','25','menu_icon_color',''),
('60','25','menu_bg_color',''),
('61','25','window_heading','Πληροφορίες ανάθεσης'),
('62','25','window_width',''),
('63','25','listing_heading','Αναθέσεις Διοικητή'),
('64','25','insert_button','Προσθήκη Ανάθεσης'),
('65','25','reports_hide_insert_button','0'),
('66','25','listing_debug_mode','0'),
('67','25','email_subject_new_item',''),
('68','25','email_subject_updated_item',''),
('69','25','disable_notification','0'),
('70','25','disable_internal_notification','0'),
('71','25','disable_highlight_unread','0'),
('72','25','use_comments','0'),
('73','25','comments_listing_type','table'),
('74','25','comments_listing_heading',''),
('75','25','comments_insert_button',''),
('76','25','comments_window_heading',''),
('77','25','display_comments_id','1'),
('78','25','display_last_comment_in_listing','1'),
('79','25','number_characters_in_comments_list',''),
('80','25','use_editor_in_comments','0'),
('81','25','disable_attachments_in_comments','1'),
('82','25','disable_avatar_in_comments','0'),
('83','25','image_preview_in_comments','0'),
('84','25','email_subject_new_comment',''),
('85','25','send_notification_to_assigned','0'),
('86','25','redirect_after_adding','subentity'),
('87','25','redirect_after_click_heading','subentity'),
('88','25','is_form_wizard','1'),
('89','25','is_form_wizard_progress_bar','1');

CREATE TABLE IF NOT EXISTS `app_entities_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entities_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `icon_color` varchar(7) NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `entities_list` text NOT NULL,
  `reports_list` text NOT NULL,
  `pages_list` text NOT NULL,
  `type` varchar(16) DEFAULT 'entity',
  `url` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `parent_item_id` int(11) NOT NULL DEFAULT 0,
  `linked_id` int(11) NOT NULL DEFAULT 0,
  `date_added` bigint(20) NOT NULL DEFAULT 0,
  `date_updated` bigint(20) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL,
  `multiple_access_groups` varchar(64) NOT NULL,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT 1,
  `field_5` tinyint(1) NOT NULL,
  `field_6` int(11) NOT NULL,
  `field_7` varchar(255) NOT NULL,
  `field_8` varchar(255) NOT NULL,
  `field_9` varchar(255) NOT NULL,
  `field_10` varchar(255) NOT NULL,
  `field_12` varchar(255) NOT NULL,
  `field_13` varchar(64) NOT NULL,
  `field_14` varchar(64) NOT NULL,
  `field_201` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_1 VALUES
('1','6231401','0','0','0','1698346901','0',NULL,'0','$P$EjCV985U.DwqXTzmANLKjDBOyiEeja0','','1','1','0','System','Administrator','admin@pm.velocitycloud.co','','admin','greek.php','blue','1698421112');

CREATE TABLE IF NOT EXISTS `app_entity_1_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_21` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `parent_item_id` int(11) DEFAULT 0,
  `linked_id` int(11) DEFAULT 0,
  `date_added` bigint(20) NOT NULL DEFAULT 0,
  `date_updated` bigint(20) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `field_156` text NOT NULL,
  `field_157` text NOT NULL,
  `field_158` text NOT NULL,
  `field_159` bigint(20) NOT NULL DEFAULT 0,
  `field_160` text NOT NULL,
  `field_161` text NOT NULL,
  `field_162` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_21 VALUES
('1','0','0','0','1698347427','0','1','0','34','37','τεστ1','0','','','');

CREATE TABLE IF NOT EXISTS `app_entity_21_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_21_values VALUES
('1','1','156','34'),
('2','1','157','37');

CREATE TABLE IF NOT EXISTS `app_entity_22` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `parent_item_id` int(11) DEFAULT 0,
  `linked_id` int(11) DEFAULT 0,
  `date_added` bigint(20) NOT NULL DEFAULT 0,
  `date_updated` bigint(20) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `field_167` text NOT NULL,
  `field_168` text NOT NULL,
  `field_169` text NOT NULL,
  `field_170` text NOT NULL,
  `field_171` text NOT NULL,
  `field_172` text NOT NULL,
  `field_173` varchar(64) NOT NULL,
  `field_174` varchar(64) NOT NULL,
  `field_175` bigint(20) NOT NULL DEFAULT 0,
  `field_176` bigint(20) NOT NULL DEFAULT 0,
  `field_177` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_22 VALUES
('1','0','1','0','1698347440','0','1','0','42','task1','46','55','','','','','0','0',''),
('2','0','1','0','1698347623','0','1','0','42','task2','46','55','','','','','0','0','');

CREATE TABLE IF NOT EXISTS `app_entity_22_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_22_values VALUES
('1','1','167','42'),
('2','1','169','46'),
('3','1','170','55'),
('4','2','167','42'),
('5','2','169','46'),
('6','2','170','55');

CREATE TABLE IF NOT EXISTS `app_entity_23` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `parent_item_id` int(11) DEFAULT 0,
  `linked_id` int(11) DEFAULT 0,
  `date_added` bigint(20) NOT NULL DEFAULT 0,
  `date_updated` bigint(20) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `field_182` text NOT NULL,
  `field_183` text NOT NULL,
  `field_184` text NOT NULL,
  `field_185` text NOT NULL,
  `field_186` text NOT NULL,
  `field_194` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_23_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_24` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT 0,
  `parent_item_id` int(11) DEFAULT 0,
  `linked_id` int(11) DEFAULT 0,
  `date_added` bigint(20) NOT NULL DEFAULT 0,
  `date_updated` bigint(20) NOT NULL DEFAULT 0,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `field_191` text NOT NULL,
  `field_192` text NOT NULL,
  `field_193` text NOT NULL,
  `field_195` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_24_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_entity_25` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned DEFAULT 0,
  `parent_item_id` int(11) unsigned DEFAULT 0,
  `linked_id` int(11) unsigned DEFAULT 0,
  `date_added` bigint(11) DEFAULT 0,
  `date_updated` bigint(11) DEFAULT 0,
  `created_by` int(11) unsigned DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `field_213` varchar(255) NOT NULL,
  `field_214` int(11) NOT NULL,
  `field_215` int(11) NOT NULL,
  `field_216` varchar(255) NOT NULL,
  `field_217` bigint(11) NOT NULL,
  `field_218` text NOT NULL,
  `field_219` text NOT NULL,
  `field_220` text NOT NULL,
  `field_221` text NOT NULL,
  `field_228` int(11) NOT NULL,
  `field_229` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_214` (`field_214`),
  KEY `idx_field_215` (`field_215`),
  KEY `idx_field_217` (`field_217`),
  KEY `idx_field_219` (`field_219`(128)),
  KEY `idx_field_221` (`field_221`(128)),
  KEY `idx_field_229` (`field_229`(128)),
  KEY `idx_field_228` (`field_228`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_25 VALUES
('1','0','0','0','1698348525','0','1','0','','68','70','fghfghfg','0','','','','1','0',''),
('2','0','0','0','1698351162','0','1','0','','68','70','test1','0','','','','1','0',''),
('3','0','0','0','1698389078','0','1','0','','69','71','test1','0','φδσδφσδ','','','1','0','');

CREATE TABLE IF NOT EXISTS `app_entity_25_values` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int(11) unsigned NOT NULL,
  `fields_id` int(11) unsigned NOT NULL,
  `value` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_entity_25_values VALUES
('1','1','221','1'),
('2','1','214','68'),
('3','1','215','70'),
('4','2','221','1'),
('5','2','214','68'),
('6','2','215','70'),
('7','3','221','1'),
('8','3','214','69'),
('9','3','215','71');

CREATE TABLE IF NOT EXISTS `app_ext_calendar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `enable_ical` tinyint(1) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `view_modes` varchar(255) NOT NULL,
  `event_limit` smallint(6) NOT NULL,
  `highlighting_weekends` varchar(64) NOT NULL,
  `min_time` varchar(5) NOT NULL,
  `max_time` varchar(5) NOT NULL,
  `time_slot_duration` varchar(8) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `use_background` int(11) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `filters_panel` varchar(16) NOT NULL DEFAULT 'default',
  `reminder_status` tinyint(1) NOT NULL,
  `reminder_type` varchar(64) NOT NULL,
  `reminder_minutes` smallint(6) NOT NULL,
  `reminder_item_heading` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_calendar_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendar_id` int(11) DEFAULT NULL,
  `calendar_type` varchar(16) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calendar_id` (`calendar_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_calendar_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `start_date` bigint(20) unsigned NOT NULL,
  `end_date` bigint(20) NOT NULL,
  `event_type` varchar(16) NOT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `repeat_type` varchar(16) NOT NULL,
  `repeat_interval` int(11) DEFAULT NULL,
  `repeat_days` varchar(16) NOT NULL,
  `repeat_end` int(11) DEFAULT NULL,
  `repeat_limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_call_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  `direction` varchar(16) NOT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `sms_text` text NOT NULL,
  `recording` text NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `is_star` tinyint(1) NOT NULL DEFAULT 0,
  `is_new` tinyint(1) NOT NULL DEFAULT 1,
  `module` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_direction` (`direction`),
  KEY `idx_phone` (`phone`),
  KEY `idx_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `menu_icon_color` varchar(16) NOT NULL,
  `assigned_to` text NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_conversations_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversations_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_conversations_id` (`conversations_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `message` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_users_assigned` (`users_id`,`assigned_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_unread_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `assigned_to` int(11) NOT NULL,
  `messages_id` int(11) NOT NULL,
  `conversations_id` int(11) NOT NULL,
  `notification_status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_messages_id` (`messages_id`),
  KEY `idx_conversations_id` (`conversations_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_users_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `date_check` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_comments_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_comments_templates_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templates_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_templates_id` (`templates_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_cryptopro_certificates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `thumbprint` varchar(64) NOT NULL,
  `certbase64` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `thumbprint` (`thumbprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_default` tinyint(1) NOT NULL,
  `title` varchar(64) NOT NULL,
  `code` varchar(16) NOT NULL,
  `symbol` varchar(16) NOT NULL,
  `value` float(13,8) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_email_notification_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `action_type` varchar(64) NOT NULL,
  `send_to_users` text NOT NULL,
  `send_to_user_group` text NOT NULL,
  `send_to_email` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `notes` text NOT NULL,
  `listing_type` varchar(16) NOT NULL,
  `listing_html` text NOT NULL,
  `listing_fields` text NOT NULL,
  `notification_days` varchar(255) NOT NULL,
  `notification_time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_email_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `action_type` varchar(64) NOT NULL,
  `send_to_users` text NOT NULL,
  `send_to_assigned_users` text NOT NULL,
  `send_to_email` text NOT NULL,
  `send_to_assigned_email` text NOT NULL,
  `monitor_fields_id` int(11) NOT NULL,
  `monitor_choices` text NOT NULL,
  `date_fields_id` int(11) NOT NULL,
  `number_of_days` varchar(32) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `send_from_name` varchar(255) NOT NULL,
  `send_from_email` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `attach_attachments` tinyint(1) NOT NULL,
  `attach_template` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_monitor_fields_id` (`monitor_fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_email_rules_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_entities_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_entities_templates_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templates_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_templates_id` (`templates_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_export_selected` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `type` varchar(64) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `template_filename` varchar(64) NOT NULL,
  `export_fields` text NOT NULL,
  `export_url` tinyint(1) NOT NULL,
  `filename` varchar(128) NOT NULL,
  `settings` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_export_selected_blocks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `block_type` varchar(32) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `settings` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templates_id` (`templates_id`),
  KEY `fields_id` (`fields_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_export_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'html',
  `label_size` varchar(16) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `template_filename` varchar(255) NOT NULL,
  `save_as` varchar(32) NOT NULL,
  `save_attachments` varchar(255) NOT NULL,
  `template_css` text NOT NULL,
  `page_orientation` varchar(16) NOT NULL,
  `split_into_pages` tinyint(1) NOT NULL DEFAULT 1,
  `template_header` text NOT NULL,
  `template_footer` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_file_storage_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modules_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_file_storage_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `modules_id` int(11) NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_functions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `reports_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `functions_name` varchar(32) NOT NULL,
  `functions_formula` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_funnelchart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(16) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `group_by_field` int(11) NOT NULL,
  `hide_zero_values` tinyint(1) NOT NULL,
  `exclude_choices` text NOT NULL,
  `sum_by_field` text NOT NULL,
  `users_groups` text NOT NULL,
  `colors` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `weekends` varchar(16) NOT NULL,
  `gantt_date_format` varchar(16) NOT NULL,
  `progress` int(11) DEFAULT NULL,
  `fields_in_listing` text NOT NULL,
  `use_background` int(11) NOT NULL DEFAULT 0,
  `default_fields_in_listing` varchar(64) NOT NULL,
  `grid_width` smallint(6) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `skin` varchar(32) NOT NULL,
  `auto_scheduling` tinyint(1) NOT NULL,
  `highlight_critical_path` tinyint(1) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ganttchart_id` int(11) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ganttchart_id` (`ganttchart_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart_depends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ganttchart_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `depends_id` int(11) NOT NULL,
  `type` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_depends_id` (`depends_id`),
  KEY `idx_ganttchart_id` (`ganttchart_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_global_search_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `fields_for_search` text NOT NULL,
  `fields_in_listing` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_graphicreport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `xaxis` int(11) NOT NULL,
  `yaxis` varchar(255) NOT NULL,
  `allowed_groups` text NOT NULL,
  `chart_type` varchar(16) NOT NULL,
  `period` text NOT NULL,
  `show_totals` tinyint(1) NOT NULL,
  `hide_zero` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_image_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `scale` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_import_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `multilevel_import` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `import_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `filepath` varchar(255) NOT NULL,
  `import_action` varchar(16) NOT NULL,
  `filetype` varchar(8) NOT NULL,
  `file_encoding` varchar(16) NOT NULL,
  `parent_item_id` int(11) NOT NULL,
  `text_delimiter` varchar(16) NOT NULL,
  `update_use_column` varchar(16) NOT NULL,
  `start_import_line` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ipages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `short_name` varchar(64) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `icon_color` varchar(7) NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `description` longtext DEFAULT NULL,
  `html_code` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_menu` tinyint(1) NOT NULL DEFAULT 0,
  `attachments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_item_pivot_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `related_entities_id` int(11) NOT NULL,
  `related_entities_fields` text NOT NULL,
  `position` varchar(16) NOT NULL,
  `rows_per_page` int(11) NOT NULL,
  `fields_in_listing` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_related_entities_id` (`related_entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_item_pivot_tables_calcs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL,
  `name` varchar(64) NOT NULL,
  `formula` text NOT NULL,
  `select_query` text NOT NULL,
  `where_query` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_items_export_templates_blocks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `block_type` varchar(32) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `settings` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templates_id` (`templates_id`),
  KEY `fields_id` (`fields_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_kanban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `in_menu` tinyint(1) NOT NULL DEFAULT 0,
  `heading_template` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `group_by_field` int(11) NOT NULL,
  `exclude_choices` text NOT NULL,
  `fields_in_listing` text NOT NULL,
  `sum_by_field` text NOT NULL,
  `width` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  `is_new` tinyint(1) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subject_cropped` varchar(255) NOT NULL,
  `groups_id` int(11) NOT NULL,
  `is_new_group` tinyint(1) NOT NULL,
  `body` longtext NOT NULL,
  `body_text` longtext NOT NULL,
  `to_name` text NOT NULL,
  `to_email` text NOT NULL,
  `from_name` varchar(255) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `reply_to_name` text NOT NULL,
  `reply_to_email` text NOT NULL,
  `cc_name` text NOT NULL,
  `cc_email` text NOT NULL,
  `bcc_name` text NOT NULL,
  `bcc_email` text NOT NULL,
  `attachments` text NOT NULL,
  `error_msg` tinytext NOT NULL,
  `is_sent` tinyint(1) NOT NULL,
  `is_star` tinyint(1) NOT NULL,
  `in_trash` tinyint(1) NOT NULL,
  `is_spam` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_groups_id` (`groups_id`),
  KEY `idx_to_email` (`to_email`(128)),
  KEY `idx_from_email` (`from_email`(128)),
  KEY `idx_date_added` (`date_added`),
  KEY `idx_is_new` (`is_new`),
  KEY `idx_is_sent` (`is_sent`),
  KEY `idx_is_star` (`is_star`),
  KEY `idx_in_trash` (`in_trash`),
  KEY `idx_is_spam` (`is_spam`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `bg_color` varchar(16) NOT NULL,
  `imap_server` varchar(255) NOT NULL,
  `mailbox` varchar(64) NOT NULL,
  `login` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `delete_emails` tinyint(1) NOT NULL,
  `is_fetched` tinyint(1) NOT NULL,
  `use_smtp` tinyint(1) NOT NULL,
  `smtp_server` varchar(255) NOT NULL,
  `smtp_port` varchar(16) NOT NULL,
  `smtp_encryption` varchar(16) NOT NULL,
  `smtp_login` varchar(64) NOT NULL,
  `smtp_password` varchar(64) NOT NULL,
  `send_autoreply` tinyint(1) NOT NULL,
  `autoreply_msg` text NOT NULL,
  `not_group_by_subject` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `parent_item_id` int(11) NOT NULL,
  `from_name` int(11) NOT NULL,
  `from_email` int(11) NOT NULL,
  `subject` int(11) NOT NULL,
  `body` int(11) NOT NULL,
  `attachments` int(11) NOT NULL,
  `bind_to_sender` tinyint(1) NOT NULL,
  `auto_create` int(1) NOT NULL,
  `title` varchar(64) NOT NULL,
  `hide_buttons` varchar(64) NOT NULL,
  `fields_in_listing` text NOT NULL,
  `fields_in_popup` text NOT NULL,
  `related_emails_position` varchar(16) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_entities_id` int(10) unsigned NOT NULL,
  `filters_id` int(11) NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_account_entities_id` (`account_entities_id`) USING BTREE,
  KEY `idx_filters_id` (`filters_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_entities_id` int(11) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  `parent_item_id` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account_entities_id` (`account_entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_entities_id` int(11) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account_entities_id` (`account_entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `send_mail_as` varchar(128) NOT NULL,
  `signature` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_name` (`name`(128)),
  KEY `idx_email` (`email`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  `action` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `subject_cropped` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_check` (`accounts_id`,`subject_cropped`(191)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_groups_from` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_groups_id` int(11) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mail_groups_id` (`mail_groups_id`,`from_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_to_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_groups_id` int(11) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_mail_groups_id` (`mail_groups_id`) USING BTREE,
  KEY `idx_from_email` (`from_email`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_map_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `background` int(11) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `display_sidebar` tinyint(1) NOT NULL,
  `fields_in_sidebar` text NOT NULL,
  `sidebar_width` varchar(16) NOT NULL,
  `zoom` tinyint(1) NOT NULL,
  `latlng` varchar(16) NOT NULL,
  `is_public_access` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mind_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `use_background` int(11) NOT NULL,
  `icons` text NOT NULL,
  `fields_in_popup` text NOT NULL,
  `shape` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(32) NOT NULL,
  `module` varchar(64) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_modules_cfg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modules_id` int(10) unsigned NOT NULL,
  `cfg_key` varchar(64) NOT NULL,
  `cfg_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `view_modes` varchar(255) NOT NULL,
  `event_limit` smallint(6) NOT NULL DEFAULT 6,
  `highlighting_weekends` varchar(64) NOT NULL,
  `min_time` varchar(5) NOT NULL,
  `max_time` varchar(5) NOT NULL,
  `time_slot_duration` varchar(8) NOT NULL,
  `display_legend` tinyint(1) NOT NULL DEFAULT 0,
  `in_menu` tinyint(1) NOT NULL,
  `users_groups` text NOT NULL,
  `enable_ical` tinyint(1) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_calendars_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `bg_color` varchar(10) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `background` varchar(10) NOT NULL,
  `use_background` int(11) NOT NULL,
  `reminder_status` tinyint(1) NOT NULL,
  `reminder_type` varchar(64) NOT NULL,
  `reminder_minutes` smallint(6) NOT NULL,
  `reminder_item_heading` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calendars_id` (`calendars_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_map_reports` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `is_public_access` tinyint(1) NOT NULL DEFAULT 0,
  `in_menu` tinyint(1) NOT NULL,
  `zoom` tinyint(1) NOT NULL,
  `latlng` varchar(16) NOT NULL,
  `display_legend` tinyint(1) NOT NULL,
  `display_sidebar` tinyint(1) NOT NULL,
  `sidebar_width` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_map_reports_entities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `background` int(11) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `fields_in_sidebar` text NOT NULL,
  `marker_color` varchar(16) NOT NULL,
  `marker_icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `filters_panel` varchar(16) NOT NULL,
  `height` smallint(6) NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  `chart_type` varchar(16) NOT NULL,
  `chart_position` varchar(16) NOT NULL,
  `chart_height` smallint(6) NOT NULL,
  `colors` text NOT NULL,
  `chart_types` text NOT NULL,
  `chart_show_labels` tinyint(1) NOT NULL,
  `chart_number_format` varchar(6) NOT NULL,
  `chart_number_prefix` varchar(16) NOT NULL,
  `chart_number_suffix` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `fields_name` varchar(64) NOT NULL,
  `cfg_date_format` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entitites_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `allow_edit` tinyint(1) NOT NULL,
  `cfg_numer_format` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `reports_settings` text NOT NULL,
  `view_mode` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pivotreports_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `fields_name` varchar(64) NOT NULL,
  `cfg_date_format` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pivotreports_id` (`pivotreports_id`),
  KEY `idx_entitites_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `reports_settings` text NOT NULL,
  `view_mode` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_process_form_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `forms_tabs_id` int(11) NOT NULL,
  `columns` tinyint(4) NOT NULL,
  `column1_width` tinyint(4) NOT NULL,
  `column2_width` tinyint(4) NOT NULL,
  `column3_width` tinyint(4) NOT NULL,
  `column4_width` tinyint(4) NOT NULL,
  `column5_width` tinyint(4) NOT NULL,
  `column6_width` tinyint(4) NOT NULL,
  `field_name_new_row` tinyint(1) NOT NULL,
  `column1_fields` text NOT NULL,
  `column2_fields` text NOT NULL,
  `column3_fields` text NOT NULL,
  `column4_fields` text NOT NULL,
  `column5_fields` text NOT NULL,
  `column6_fields` text NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`process_id`),
  KEY `forms_tabs_id` (`forms_tabs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_process_form_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `fields` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_process_id` (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(255) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `print_template` varchar(32) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `assigned_to_all` tinyint(1) NOT NULL,
  `access_to_assigned` text NOT NULL,
  `window_width` varchar(64) NOT NULL,
  `confirmation_text` text NOT NULL,
  `warning_text` text NOT NULL,
  `allow_comments` tinyint(1) unsigned NOT NULL,
  `preview_prcess_actions` tinyint(1) unsigned NOT NULL,
  `notes` text NOT NULL,
  `payment_modules` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `apply_fields_access_rules` tinyint(1) NOT NULL DEFAULT 0,
  `apply_fields_display_rules` tinyint(1) NOT NULL,
  `hide_entity_name` tinyint(1) NOT NULL DEFAULT 0,
  `success_message` text NOT NULL,
  `success_message_status` tinyint(1) NOT NULL DEFAULT 1,
  `redirect_to_items_listing` tinyint(1) NOT NULL DEFAULT 0,
  `disable_comments` tinyint(1) NOT NULL,
  `javascript_in_from` text NOT NULL,
  `javascript_onsubmit` text NOT NULL,
  `is_form_wizard` tinyint(1) NOT NULL DEFAULT 0,
  `is_form_wizard_progress_bar` tinyint(4) NOT NULL,
  `submit_button_title` varchar(32) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `process_id` int(64) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `type` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_process_id` (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes_actions_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actions_id` int(10) unsigned NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  `value` text NOT NULL,
  `enter_manually` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_actions_id` (`actions_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes_buttons_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes_clone_subitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actions_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `from_entity_id` int(11) NOT NULL,
  `to_entity_id` int(11) NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_from_entity_id` (`from_entity_id`),
  KEY `idx_to_entity_id` (`to_entity_id`),
  KEY `idx_actions_id` (`actions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_public_forms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) unsigned NOT NULL,
  `parent_item_id` int(11) NOT NULL,
  `hide_parent_item` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `inactive_message` text NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `button_save_title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `successful_sending_message` text NOT NULL,
  `after_submit_action` varchar(32) NOT NULL,
  `after_submit_redirect` varchar(255) NOT NULL,
  `user_agreement` text NOT NULL,
  `hidden_fields` text NOT NULL,
  `customer_name` varchar(64) NOT NULL,
  `customer_email` int(11) NOT NULL,
  `customer_message_title` varchar(255) NOT NULL,
  `customer_message` text NOT NULL,
  `admin_name` varchar(64) NOT NULL,
  `admin_email` varchar(64) NOT NULL,
  `admin_notification` tinyint(1) NOT NULL,
  `check_enquiry` tinyint(1) NOT NULL,
  `disable_submit_form` tinyint(1) NOT NULL,
  `check_page_title` varchar(255) NOT NULL,
  `check_page_description` text NOT NULL,
  `check_button_title` varchar(64) NOT NULL,
  `check_page_fields` text NOT NULL,
  `check_page_comments` tinyint(1) NOT NULL,
  `check_page_comments_heading` varchar(255) NOT NULL,
  `check_page_comments_fields` text NOT NULL,
  `notify_field_change` int(11) unsigned NOT NULL,
  `notify_message_title` varchar(255) NOT NULL,
  `notify_message_body` text NOT NULL,
  `check_enquiry_fields` varchar(255) NOT NULL,
  `form_css` text NOT NULL,
  `form_js` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_recurring_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `repeat_type` varchar(16) NOT NULL,
  `repeat_interval` int(11) NOT NULL,
  `repeat_days` varchar(16) NOT NULL,
  `repeat_start` bigint(20) unsigned NOT NULL,
  `repeat_end` bigint(20) unsigned NOT NULL,
  `repeat_limit` int(11) NOT NULL,
  `repeat_time` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_recurring_tasks_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tasks_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_id` (`tasks_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_report_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `type` varchar(64) NOT NULL,
  `use_editor` tinyint(1) NOT NULL,
  `save_filename` varchar(255) NOT NULL,
  `save_as` varchar(16) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` varchar(255) NOT NULL,
  `assigned_to` varchar(255) NOT NULL,
  `page_orientation` varchar(16) NOT NULL,
  `settings` text NOT NULL,
  `css` longtext NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_report_page_blocks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `block_type` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `field_id` int(11) NOT NULL,
  `settings` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `report_id` (`report_id`) USING BTREE,
  KEY `field_id` (`field_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_resource_timeline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `fields_in_listing` varchar(255) NOT NULL,
  `display_legend` tinyint(1) NOT NULL,
  `listing_width` varchar(4) NOT NULL,
  `column_width` varchar(64) NOT NULL,
  `fields_in_popup` varchar(255) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `min_time` varchar(5) NOT NULL,
  `max_time` varchar(5) NOT NULL,
  `view_modes` varchar(255) NOT NULL,
  `time_slot_duration` varchar(8) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_resource_timeline_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `related_entity_field_id` int(11) NOT NULL,
  `bg_color` varchar(10) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `background` varchar(10) NOT NULL,
  `use_background` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calendars_id` (`calendars_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_rss_feeds` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rss_id` int(10) unsigned NOT NULL,
  `entities_id` int(10) unsigned NOT NULL,
  `type` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `start_date` int(10) unsigned NOT NULL,
  `end_date` int(10) unsigned NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rss_id` (`rss_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_signed_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `date_added` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(64) NOT NULL,
  `inn` varchar(64) NOT NULL,
  `ogrn` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `items_id` (`items_id`),
  KEY `users_id` (`users_id`),
  KEY `fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_signed_items_signatures` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `signed_items_id` int(11) NOT NULL,
  `signed_text` text NOT NULL,
  `singed_filename` varchar(255) NOT NULL,
  `signature` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `signed_items_id` (`signed_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_smart_input_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modules_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `rules` text NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_modules_id` (`modules_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_sms_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `modules_id` int(11) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `action_type` varchar(64) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `monitor_fields_id` int(11) NOT NULL,
  `monitor_choices` text NOT NULL,
  `date_fields_id` int(11) NOT NULL,
  `date_type` varchar(16) NOT NULL,
  `number_of_days` varchar(32) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `send_to_assigned_users` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`),
  KEY `idx_monitor_fields_id` (`monitor_fields_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_subscribe_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `modules_id` int(11) NOT NULL,
  `contact_list_id` varchar(255) NOT NULL,
  `contact_email_field_id` int(11) NOT NULL,
  `contact_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`),
  KEY `idx_fields_id` (`contact_email_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_timeline_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `in_menu` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `use_background` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_timer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `seconds` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_timer_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_track_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `position` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `track_actions` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `color_insert` varchar(7) NOT NULL,
  `color_update` varchar(7) NOT NULL,
  `color_comment` varchar(7) NOT NULL,
  `color_delete` varchar(7) NOT NULL,
  `rows_per_page` smallint(6) NOT NULL,
  `keep_history` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `track_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `comments_id` int(11) NOT NULL,
  `items_name` varchar(255) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_cron` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_comments_id` (`comments_id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_log_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_log_id` (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_xml_export_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `template_header` text NOT NULL,
  `template_body` text NOT NULL,
  `template_footer` text NOT NULL,
  `template_filename` varchar(255) NOT NULL,
  `transliterate_filename` tinyint(1) NOT NULL DEFAULT 0,
  `related_entities_template` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_ext_xml_import_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `data_path` varchar(255) NOT NULL,
  `import_fields` text NOT NULL,
  `import_fields_path` text NOT NULL,
  `import_action` varchar(16) NOT NULL,
  `update_by_field` int(11) NOT NULL,
  `update_by_field_path` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `parent_item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_Id` (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `forms_tabs_id` int(11) NOT NULL,
  `comments_forms_tabs_id` int(11) NOT NULL DEFAULT 0,
  `forms_rows_position` varchar(255) NOT NULL,
  `type` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_name` varchar(64) NOT NULL,
  `is_heading` tinyint(1) DEFAULT 0,
  `tooltip` text NOT NULL,
  `tooltip_display_as` varchar(16) NOT NULL,
  `tooltip_in_item_page` tinyint(1) NOT NULL DEFAULT 0,
  `tooltip_item_page` text NOT NULL,
  `notes` text NOT NULL,
  `is_required` tinyint(1) DEFAULT 0,
  `required_message` text NOT NULL,
  `configuration` text NOT NULL,
  `sort_order` int(11) DEFAULT 0,
  `listing_status` tinyint(4) NOT NULL DEFAULT 0,
  `listing_sort_order` int(11) NOT NULL DEFAULT 0,
  `comments_status` tinyint(1) NOT NULL DEFAULT 0,
  `comments_sort_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_form_tabs_id` (`forms_tabs_id`),
  KEY `idx_comments_forms_tabs_id` (`comments_forms_tabs_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_fields VALUES
('1','1','1','0','','fieldtype_action','','',NULL,'','','0','','',NULL,'','',NULL,'1','0','0','0'),
('2','1','1','0','','fieldtype_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','1','0','0'),
('3','1','1','0','','fieldtype_date_added','','',NULL,'','','0','','',NULL,'','',NULL,'0','0','0','0'),
('4','1','1','0','','fieldtype_created_by','','',NULL,'','','0','','',NULL,'','',NULL,'0','0','0','0'),
('5','1','1','0','','fieldtype_user_status','','',NULL,'','','0','','',NULL,'','','0','1','7','0','0'),
('6','1','1','0','','fieldtype_user_accessgroups','','',NULL,'','','0','','',NULL,'','','1','1','2','0','0'),
('7','1','1','0','','fieldtype_user_firstname','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','3','1','4','0','0'),
('8','1','1','0','','fieldtype_user_lastname','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','4','1','5','0','0'),
('9','1','1','0','','fieldtype_user_email','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','6','1','6','0','0'),
('10','1','1','0','','fieldtype_user_photo','','',NULL,'','','0','','',NULL,'','','5','0','0','0','0'),
('12','1','1','0','','fieldtype_user_username','','','1','','','0','','',NULL,'','{\"allow_search\":\"1\"}','2','1','3','0','0'),
('13','1','1','0','','fieldtype_user_language','','','0','','','0','','','0','','','7','0','0','0','0'),
('14','1','1','0','','fieldtype_user_skin','','','0','','','0','','','0','','','0','0','0','0','0'),
('152','21','24','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('153','21','24','0','','fieldtype_id','','','0','','','0','','','0','','','0','1','1','0','0'),
('154','21','24','0','','fieldtype_date_added','','','0','','','0','','','0','','','0','1','6','0','0'),
('155','21','24','0','','fieldtype_created_by','','','0','','','0','','','0','','','0','1','7','0','0'),
('156','21','24','0','','fieldtype_dropdown','Priority','','0','','','0','','','1','','{\"width\":\"input-medium\"}','0','1','2','1','0'),
('157','21','24','0','','fieldtype_dropdown','Status','','0','','','0','','','1','','{\"width\":\"input-medium\"}','1','1','4','1','1'),
('158','21','24','0','','fieldtype_input','Name','','1','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-xlarge\"}','2','1','3','0','0'),
('159','21','24','0','','fieldtype_input_date','Start Date','','0','','','0','','','0','','','3','1','5','0','0'),
('160','21','24','0','','fieldtype_textarea_wysiwyg','Description','','0','','','0','','','0','','{\"allow_search\":\"1\"}','4','0','0','0','0'),
('161','21','25','0','','fieldtype_users','Team','','0','','','0','','','0','','{\"display_as\":\"checkboxes\"}','0','0','0','0','0'),
('162','21','24','0','','fieldtype_attachments','Attachments','','0','','','0','','','0','','','5','0','0','0','0'),
('163','22','26','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('164','22','26','0','','fieldtype_id','','','0','','','0','','','0','','','0','1','1','0','0'),
('165','22','26','0','','fieldtype_date_added','','','0','','','0','','','0','','','0','1','10','0','0'),
('166','22','26','0','','fieldtype_created_by','','','0','','','0','','','0','','','0','1','11','0','0'),
('167','22','26','0','','fieldtype_dropdown','Type','','0','','','0','','','1','','{\"width\":\"input-medium\"}','1','1','3','0','0'),
('168','22','26','0','','fieldtype_input','Name','','1','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-xlarge\"}','2','1','4','0','0'),
('169','22','26','0','','fieldtype_dropdown','Status','','0','','','0','','','1','','{\"width\":\"input-large\"}','3','1','5','1','0'),
('170','22','26','0','','fieldtype_dropdown','Priority','','0','','','0','','','1','','{\"width\":\"input-medium\"}','4','1','2','1','1'),
('171','22','26','0','','fieldtype_users','Assigned To','','0','','','0','','','0','','{\"display_as\":\"checkboxes\"}','5','1','6','0','0'),
('172','22','26','0','','fieldtype_textarea_wysiwyg','Description','','0','','','0','','','0','','{\"allow_search\":\"1\"}','6','0','0','0','0'),
('173','22','27','0','','fieldtype_input_numeric','Est. Time','','0','','','0','','','0','','{\"width\":\"input-small\",\"number_format\":\"2/./*\"}','1','1','7','0','0'),
('174','22','27','0','','fieldtype_input_numeric_comments','Work Hours','','0','','','0','','','0','','','2','1','8','1','2'),
('175','22','27','0','','fieldtype_input_date','Start Date','','0','','','0','','','0','','','3','0','0','0','0'),
('176','22','27','0','','fieldtype_input_date','End Date','','0','','','0','','','0','','','4','1','9','0','0'),
('177','22','26','0','','fieldtype_attachments','Attachments','','0','','','0','','','0','','','7','0','0','0','0'),
('178','23','28','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('179','23','28','0','','fieldtype_id','','','0','','','0','','','0','','','0','1','1','0','0'),
('180','23','28','0','','fieldtype_date_added','','','0','','','0','','','0','','','0','1','6','0','0'),
('181','23','28','0','','fieldtype_created_by','','','0','','','0','','','0','','','0','1','7','0','0'),
('182','23','28','0','','fieldtype_grouped_users','Department','','0','','','0','','','1','','','0','1','4','1','0'),
('183','23','28','0','','fieldtype_dropdown','Type','','0','','','0','','','1','','{\"width\":\"input-large\"}','2','1','2','1','1'),
('184','23','28','0','','fieldtype_input','Subject','','1','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-xlarge\"}','3','1','3','0','0'),
('185','23','28','0','','fieldtype_textarea_wysiwyg','Description','','0','','','0','','','0','','{\"allow_search\":\"1\"}','4','0','0','0','0'),
('186','23','28','0','','fieldtype_dropdown','Status','','0','','','0','','','1','','{\"width\":\"input-large\"}','1','1','5','1','2'),
('187','24','29','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('188','24','29','0','','fieldtype_id','','','0','','','0','','','0','','','0','1','1','0','0'),
('189','24','29','0','','fieldtype_date_added','','','0','','','0','','','0','','','0','1','4','0','0'),
('190','24','29','0','','fieldtype_created_by','','','0','','','0','','','0','','','0','1','5','0','0'),
('191','24','29','0','','fieldtype_input','Name','','1','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-xlarge\"}','1','1','3','0','0'),
('192','24','29','0','','fieldtype_textarea_wysiwyg','Description','','0','','','0','','','0','','{\"allow_search\":\"1\"}','2','0','0','0','0'),
('193','24','29','0','','fieldtype_dropdown','Status','','0','','','0','','','0','','{\"width\":\"input-medium\"}','0','1','2','1','0'),
('194','23','28','0','','fieldtype_attachments','Attachments','','0','','','0','','','0','','','5','0','0','0','0'),
('195','24','29','0','','fieldtype_attachments','Attachments','','0','','','0','','','0','','','3','0','0','0','0'),
('196','1','1','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('197','21','24','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('198','22','26','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('199','23','28','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('200','24','29','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('201','1','1','0','','fieldtype_user_last_login_date','','','0','','','0','','','0','','','0','0','0','0','0'),
('202','1','1','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('203','21','24','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('204','22','26','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('205','23','28','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('206','24','29','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('207','25','30','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('208','25','30','0','','fieldtype_id','','','0','','','0','','','0','','','1','1','1','0','0'),
('209','25','30','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','1','2','0','0'),
('210','25','30','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','1','3','0','0'),
('211','25','30','0','','fieldtype_created_by','','','0','','','0','','','0','','','4','1','4','0','0'),
('212','25','30','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','5','0','0'),
('213','25','30','0','','fieldtype_input','Περιγραφή','','0','','','0','','','0','','{\"width\":\"input-small\",\"default_value\":\"\",\"is_unique\":\"0\",\"unique_error_msg\":\"\"}','8','0','0','0','0'),
('214','25','30','0','','fieldtype_dropdown','Priority','','0','','','0','','','1','','{\"width\":\"input-medium\"}','1','1','2','1','0'),
('215','25','30','0','','fieldtype_dropdown','Status','','0','','','0','','','1','','{\"width\":\"input-medium\"}','3','1','4','1','1'),
('216','25','30','0','','fieldtype_input','Name','','0','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-xlarge\"}','4','1','3','0','0'),
('217','25','30','0','','fieldtype_input_date','Start Date','','0','','','0','','','0','','','5','1','5','0','0'),
('218','25','30','0','','fieldtype_textarea_wysiwyg','Description','','0','','','0','','','0','','{\"allow_search\":\"1\"}','6','0','0','0','0'),
('219','25','30','0','','fieldtype_users','Team','','0','','','0','','','0','','{\"display_as\":\"checkboxes\"}','2','0','0','0','0'),
('220','25','30','0','','fieldtype_attachments','Attachments','','0','','','0','','','0','','','7','0','0','0','0'),
('221','25','31','0','','fieldtype_users','Team','','0','','','0','','','0','','{\"display_as\":\"checkboxes\"}','0','0','0','0','0'),
('228','25','30','0','','fieldtype_entity_multilevel','Project','','0','','','0','','','0','','{\"entity_id\":\"21\",\"width\":\"input-medium\",\"heading_template\":\"\",\"copy_values\":\"\"}','0','0','0','0','0'),
('229','25','30','0','','fieldtype_entity_ajax','test2','','0','','','0','','','0','','{\"entity_id\":\"22\",\"width\":\"input-medium\",\"display_as\":\"dropdown_multiple\",\"default_text\":\"\",\"default_value\":\"\",\"heading_template\":\"\",\"copy_values\":\"\",\"mysql_query_where\":\"\"}','9','0','0','0','0');

CREATE TABLE IF NOT EXISTS `app_fields_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_groups_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_fields_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `fields_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `users` text NOT NULL,
  `value` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_fields_choices VALUES
('34','0','156','1','Urgent','0','','1','','',''),
('35','0','156','1','High','0','','2','','',''),
('37','0','157','1','New','0','','1','','',''),
('38','0','157','1','Open','0','','2','','',''),
('39','0','157','1','Waiting','0','','3','','',''),
('40','0','157','1','Closed','0','','4','','',''),
('41','0','157','1','Canceled','0','','5','','',''),
('42','0','167','1','Task','1','','1','','',''),
('43','0','167','1','Change','0','','2','','',''),
('44','0','167','1','Bug','0','#ff7a00','3','','',''),
('45','0','167','1','Idea','0','','0','','',''),
('46','0','169','1','New','1','','0','','',''),
('47','0','169','1','Open','0','','2','','',''),
('48','0','169','1','Waiting','0','','3','','',''),
('49','0','169','1','Done','0','','4','','',''),
('50','0','169','1','Closed','0','','5','','',''),
('51','0','169','1','Paid','0','','6','','',''),
('52','0','169','1','Canceled','0','','7','','',''),
('53','0','170','1','Urgent','0','#ff0000','1','','',''),
('54','0','170','1','High','0','','2','','',''),
('55','0','170','1','Medium','1','','3','','',''),
('56','0','182','1','Support','0','','0','','',''),
('57','0','183','1','Request a Change','0','','1','','',''),
('58','0','183','1','Report a Bug','0','','2','','',''),
('59','0','183','1','Ask a Question','0','','3','','',''),
('60','0','186','1','New','1','','0','','',''),
('61','0','186','1','Open','0','','2','','',''),
('62','0','186','1','Waiting On Client','0','','3','','',''),
('63','0','186','1','Closed','0','','4','','',''),
('64','0','186','1','Canceled','0','','5','','',''),
('65','0','193','1','Open','0','','1','','',''),
('66','0','193','1','Closed','0','','2','','',''),
('67','0','193','1','New','1','','0','','',''),
('68','0','214','1','Urgent','0','','1','','',''),
('69','0','214','1','High','0','','2','','',''),
('70','0','215','1','New','0','','1','','',''),
('71','0','215','1','Open','0','','2','','',''),
('72','0','215','1','Waiting','0','','3','','',''),
('73','0','215','1','Closed','0','','4','','',''),
('74','0','215','1','Canceled','0','','5','','','');

CREATE TABLE IF NOT EXISTS `app_filters_panels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_active_filters` tinyint(1) NOT NULL,
  `position` varchar(16) NOT NULL,
  `users_groups` text NOT NULL,
  `width` tinyint(1) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_filters_panels_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `panels_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `width` varchar(16) NOT NULL,
  `height` varchar(16) NOT NULL,
  `display_type` varchar(32) NOT NULL,
  `search_type_match` tinyint(1) NOT NULL,
  `exclude_values` text NOT NULL,
  `exclude_values_not_in_listing` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_panels_id` (`panels_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_forms_fields_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(10) unsigned NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `choices` text NOT NULL,
  `visible_fields` text NOT NULL,
  `hidden_fields` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_forms_fields_rules VALUES
('1','25','214','1','69','228,219,215,216,217,218,220,213','229','0');

CREATE TABLE IF NOT EXISTS `app_forms_rows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `forms_tabs_id` int(11) NOT NULL,
  `columns` tinyint(4) NOT NULL,
  `column1_width` tinyint(4) NOT NULL,
  `column2_width` tinyint(4) NOT NULL,
  `column3_width` tinyint(4) NOT NULL,
  `column4_width` tinyint(4) NOT NULL,
  `column5_width` tinyint(4) NOT NULL,
  `column6_width` tinyint(4) NOT NULL,
  `field_name_new_row` tinyint(1) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `forms_tabs_id` (`forms_tabs_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_forms_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `is_folder` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_forms_tabs VALUES
('1','1','0','0','Info','','0'),
('24','21','0','0','Info','','0'),
('25','21','0','0','Team','','1'),
('26','22','0','0','Info','','0'),
('27','22','0','0','Time','','1'),
('28','23','0','0','Info','','0'),
('29','24','0','0','Info','','0'),
('30','25','0','0','Info','','0'),
('31','25','0','0','Team','','1');

CREATE TABLE IF NOT EXISTS `app_global_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_global_lists_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `lists_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `value` varchar(64) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `users` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_lists_id` (`lists_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_global_vars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `is_folder` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(255) NOT NULL,
  `notes` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_help_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `start_date` int(11) NOT NULL,
  `end_date` int(11) NOT NULL,
  `description` text NOT NULL,
  `color` varchar(16) NOT NULL,
  `position` varchar(16) NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_image_map_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `choices_id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_map_id` (`map_id`),
  KEY `idx_choices_id` (`choices_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_image_map_markers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_map_id` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_image_map_markers_nested` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_items_export_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `templates_fields` text NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cidx` (`entities_id`,`users_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_listing_highlight_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `fields_id` int(10) unsigned NOT NULL,
  `fields_values` text NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `entities_id` (`entities_id`),
  KEY `fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_listing_highlight_rules VALUES
('1','25','1','228','1','','0','');

CREATE TABLE IF NOT EXISTS `app_listing_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listing_types_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields` text NOT NULL,
  `display_as` varchar(16) NOT NULL,
  `display_field_names` tinyint(1) NOT NULL,
  `text_align` varchar(16) NOT NULL,
  `width` varchar(16) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_listing_types_id` (`listing_types_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_listing_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_default` tinyint(4) NOT NULL,
  `width` smallint(6) NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_listing_types VALUES
('1','25','table','1','1','0',''),
('2','25','tree_table','0','0','0',''),
('3','25','list','0','0','0',''),
('4','25','grid','0','0','0',''),
('5','25','mobile','0','0','0','');

CREATE TABLE IF NOT EXISTS `app_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int(11) unsigned NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `log_type` varchar(16) NOT NULL,
  `date_added` int(11) NOT NULL,
  `http_url` varchar(255) NOT NULL,
  `is_ajax` tinyint(1) NOT NULL,
  `description` text NOT NULL,
  `seconds` decimal(11,4) NOT NULL,
  `errno` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `linenum` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_date_added` (`date_added`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_log_type` (`log_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_mind_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) DEFAULT NULL,
  `fields_id` int(11) DEFAULT NULL,
  `reports_id` int(11) DEFAULT NULL,
  `mm_id` varchar(64) NOT NULL,
  `mm_parent_id` varchar(64) NOT NULL,
  `mm_text` varchar(255) NOT NULL,
  `mm_layout` varchar(16) NOT NULL,
  `mm_shape` varchar(16) NOT NULL,
  `mm_side` varchar(16) NOT NULL,
  `mm_color` varchar(16) NOT NULL,
  `mm_icon` varchar(32) NOT NULL,
  `mm_collapsed` varchar(1) NOT NULL,
  `mm_value` varchar(64) NOT NULL,
  `mm_items_id` int(11) DEFAULT 0,
  `parent_entity_item_id` int(11) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_nested_entities_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `entities` varchar(255) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `icon_color` varchar(10) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_portlets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `users_id` int(11) NOT NULL,
  `is_collapsed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`,`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_portlets VALUES
('1','filters_preview_68','1','0'),
('2','filters_preview_72','1','0'),
('3','dashboard_standard_report76','1','0');

CREATE TABLE IF NOT EXISTS `app_records_visibility_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `users_groups` text NOT NULL,
  `merged_fields` text NOT NULL,
  `merged_fields_empty_values` text NOT NULL,
  `notes` text NOT NULL,
  `mysql_query` text NOT NULL,
  `php_code` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_related_items_21_25` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `entity_25_items_id` int(11) unsigned NOT NULL,
  `entity_21_items_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_25_items_id` (`entity_25_items_id`),
  KEY `idx_21_items_id` (`entity_21_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS `app_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `entities_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `reports_type` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `icon_color` varchar(7) NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `in_menu` tinyint(1) NOT NULL DEFAULT 0,
  `in_dashboard` tinyint(4) NOT NULL DEFAULT 0,
  `in_dashboard_counter` tinyint(1) NOT NULL DEFAULT 0,
  `in_dashboard_icon` tinyint(1) NOT NULL,
  `in_dashboard_counter_color` varchar(16) NOT NULL,
  `in_dashboard_counter_bg_color` varchar(16) NOT NULL,
  `in_dashboard_counter_fields` varchar(255) NOT NULL,
  `dashboard_counter_hide_count` tinyint(1) NOT NULL DEFAULT 0,
  `dashboard_counter_hide_zero_count` tinyint(1) NOT NULL,
  `dashboard_counter_sum_by_field` int(11) NOT NULL,
  `in_header` tinyint(1) NOT NULL DEFAULT 0,
  `in_header_autoupdate` tinyint(1) NOT NULL,
  `dashboard_sort_order` int(11) DEFAULT NULL,
  `header_sort_order` int(11) NOT NULL DEFAULT 0,
  `dashboard_counter_sort_order` int(11) NOT NULL DEFAULT 0,
  `listing_order_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `displays_assigned_only` tinyint(1) NOT NULL DEFAULT 0,
  `parent_entity_id` int(11) NOT NULL DEFAULT 0,
  `parent_item_id` int(11) NOT NULL DEFAULT 0,
  `fields_in_listing` text NOT NULL,
  `rows_per_page` int(11) NOT NULL DEFAULT 0,
  `notification_days` varchar(32) NOT NULL,
  `notification_time` varchar(255) NOT NULL,
  `listing_type` varchar(16) NOT NULL,
  `listing_col_width` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_entity_id` (`parent_entity_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_reports_type` (`reports_type`),
  KEY `idx_in_dashboard` (`in_dashboard`),
  KEY `idx_in_dashboard_counter` (`in_dashboard_counter`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_reports VALUES
('59','0','21','0','default','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('61','0','22','0','default','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('63','0','23','0','default','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('66','0','25','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','216_asc','','','0','0','0','','0','','','',''),
('67','0','21','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('68','0','22','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','21','1','','0','','','',''),
('69','0','23','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','21','1','','0','','','',''),
('70','0','24','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','21','1','','0','','','',''),
('71','0','1','1','entity','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('72','73','22','1','standard','test re','','','','','0','0','0','0','','','','0','0','0','0','0','0','0','0','','','','0','0','0','','0','','','',''),
('73','0','21','1','parent','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('75','0','21','0','related_items_228','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','158','0','','','',''),
('76','77','22','1','standard','Antonis Skandali3','','','','','0','1','1','1','','','','0','0','0','1','1','0','0','0','','','','0','0','0','','0','','','',''),
('77','0','21','1','parent','','','','','','0','0','0','0','','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','','');

CREATE TABLE IF NOT EXISTS `app_reports_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_reports_filters VALUES
('68','59','157','37,38,39','include','1'),
('70','61','169','46,47,48','include','1'),
('72','63','186','60,61,62','include','1'),
('73','67','157','37,38,39','include','1'),
('75','69','186','60,61,62','include','1'),
('76','68','169','46,47,48','include','1'),
('77','72','171','','include','1');

CREATE TABLE IF NOT EXISTS `app_reports_filters_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cidx` (`fields_id`,`users_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_reports_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `icon_color` varchar(7) NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `in_dashboard` tinyint(1) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  `counters_list` text NOT NULL,
  `reports_list` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_common` tinyint(1) NOT NULL DEFAULT 0,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_reports_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by` int(11) NOT NULL,
  `count_columns` tinyint(1) NOT NULL DEFAULT 2,
  `reports_groups_id` int(11) NOT NULL,
  `report_left` varchar(64) NOT NULL,
  `report_right` varchar(64) NOT NULL,
  `sort_order` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_groups_id` (`reports_groups_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_reports_sections VALUES
('1','1','2','0','standard76','standard72','0');

CREATE TABLE IF NOT EXISTS `app_sessions` (
  `sesskey` varchar(32) NOT NULL,
  `expiry` bigint(20) unsigned NOT NULL,
  `value` longtext DEFAULT NULL,
  PRIMARY KEY (`sesskey`),
  KEY `idx_expiry` (`expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_user_filters_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filters_id` int(11) NOT NULL,
  `reports_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_filters_id` (`filters_id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_user_roles_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_roles_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `access_schema` varchar(255) NOT NULL,
  `comments_access` varchar(64) NOT NULL,
  `fields_access` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_user_roles_id` (`user_roles_id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_user_roles_to_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_roles_id` (`roles_id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_users_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(16) NOT NULL,
  `location` varchar(16) NOT NULL,
  `start_date` bigint(20) unsigned NOT NULL,
  `end_date` bigint(20) unsigned NOT NULL,
  `assigned_to` text NOT NULL,
  `users_groups` text NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_users_alerts_viewed` (
  `users_id` int(11) NOT NULL,
  `alerts_id` int(11) NOT NULL,
  KEY `idx_ueser_alerts` (`users_id`,`alerts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_users_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_users_configuration VALUES
('1','1','hidden_common_reports',''),
('2','1','sidebar-status',''),
('3','1','disable_notification',''),
('4','1','disable_internal_notification',''),
('5','1','disable_highlight_unread','');

CREATE TABLE IF NOT EXISTS `app_users_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `fields_in_listing` text NOT NULL,
  `listing_order_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `app_users_login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `is_success` tinyint(1) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_users_login_log VALUES
('5','1','admin','85.72.163.115','1','1698346917'),
('6','1','admin','85.72.163.115','1','1698382028'),
('7','1','admin','195.251.0.195','1','1698387425'),
('8','1','admin','85.72.163.115','1','1698418706'),
('9','1','admin','85.72.163.115','1','1698421112');

CREATE TABLE IF NOT EXISTS `app_users_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `type` varchar(16) NOT NULL,
  `date_added` bigint(20) unsigned NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_uei` (`users_id`,`entities_id`) USING BTREE,
  KEY `idx_created_by` (`created_by`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO app_users_notifications VALUES
('1','0','21','1','New Project: τεστ1','new_item','1698347427','1'),
('2','0','22','1','New Task task1 - τεστ1','new_item','1698347440','1'),
('3','0','22','2','New Task task2 - τεστ1','new_item','1698347623','1'),
('4','0','25','1','New Item: 1','new_item','1698348525','1'),
('5','0','25','2','New Item: 2','new_item','1698351162','1'),
('6','0','25','3','New Item: 3','new_item','1698389078','1');

CREATE TABLE IF NOT EXISTS `app_users_search_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `reports_id` int(11) NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_users_reports_id` (`users_id`,`reports_id`),
  KEY `idx_reports_id` (`reports_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

